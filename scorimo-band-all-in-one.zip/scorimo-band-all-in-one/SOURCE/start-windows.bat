@echo off
setlocal
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or newer is required: https://nodejs.org/
  pause
  exit /b 1
)
call corepack enable
call pnpm install
if errorlevel 1 pause & exit /b 1
call pnpm dev
