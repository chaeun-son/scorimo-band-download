@echo off
setlocal
call corepack enable
call pnpm install
if errorlevel 1 pause & exit /b 1
call pnpm test
if errorlevel 1 pause & exit /b 1
call pnpm build
if errorlevel 1 pause & exit /b 1
echo Build complete: dist\
pause
