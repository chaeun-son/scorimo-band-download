// @vitest-environment jsdom
import "@testing-library/jest-dom/vitest";
import "fake-indexeddb/auto";
import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";
import { getScore } from "./lib/scoreStorage";

const authMocks = vi.hoisted(() => ({
  user: {
    id: "test-user",
    email: "member@scorimo.band",
    user_metadata: { full_name: "테스트 멤버" },
  } as Record<string, unknown> | null,
  signInWithPassword: vi.fn().mockResolvedValue({ data: {}, error: null }),
  signUp: vi.fn().mockResolvedValue({ data: {}, error: null }),
  signInWithOAuth: vi.fn().mockResolvedValue({ data: {}, error: null }),
  resetPasswordForEmail: vi.fn().mockResolvedValue({ data: {}, error: null }),
}));

const cloudMocks = vi.hoisted(() => ({
  upload: vi.fn().mockResolvedValue({}),
  get: vi.fn().mockResolvedValue(null),
  getIds: vi.fn().mockResolvedValue([]),
  remove: vi.fn().mockResolvedValue({ success: true }),
}));

vi.mock("./lib/supabase", () => ({
  supabase: {
    auth: {
      getSession: vi.fn(() => Promise.resolve({ data: { session: authMocks.user ? { user: authMocks.user } : null } })),
      onAuthStateChange: vi.fn(() => ({
        data: { subscription: { unsubscribe: vi.fn() } },
      })),
      signOut: vi.fn().mockResolvedValue({ error: null }),
      signInWithPassword: authMocks.signInWithPassword,
      signUp: authMocks.signUp,
      signInWithOAuth: authMocks.signInWithOAuth,
      resetPasswordForEmail: authMocks.resetPasswordForEmail,
    },
  },
}));

vi.mock("./lib/scoreCloud", () => ({
  uploadCloudScore: cloudMocks.upload,
  getCloudScore: cloudMocks.get,
  getCloudScoreIds: cloudMocks.getIds,
  deleteCloudScore: cloudMocks.remove,
}));

async function renderApp() {
  render(<App />);
  await screen.findByRole("heading", { name: /밴드 운영을/, level: 2 });
}

describe("SCORIMO BAND core interactions", () => {
  beforeEach(() => {
    authMocks.user = {
      id: "test-user",
      email: "member@scorimo.band",
      user_metadata: { full_name: "테스트 멤버" },
    };
    authMocks.signInWithPassword.mockClear();
    authMocks.signInWithOAuth.mockClear();
    cloudMocks.upload.mockClear();
    localStorage.clear();
    localStorage.setItem("scorimo-v2-songs", JSON.stringify([
      { title: "Square", artist: "백예린", key: "D", bpm: 88, status: "합주 중", progress: 50 },
    ]));
    localStorage.setItem("scorimo-v2-payments", JSON.stringify([
      { name: "박성호", status: false },
    ]));
    vi.stubGlobal("prompt", vi.fn());
    vi.stubGlobal("confirm", vi.fn(() => true));
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: { writeText: vi.fn().mockResolvedValue(undefined) },
    });
    Object.defineProperty(URL, "createObjectURL", {
      configurable: true,
      value: vi.fn(() => "blob:scorimo-score"),
    });
    Object.defineProperty(URL, "revokeObjectURL", {
      configurable: true,
      value: vi.fn(),
    });
  });

  afterEach(() => {
    cleanup();
    vi.restoreAllMocks();
  });

  it("opens every primary management screen from the sidebar", async () => {
    await renderApp();
    const user = userEvent.setup();
    const navigation = screen.getByRole("navigation");
    for (const screenName of ["합주 일정", "곡 관리", "악보실", "회비 관리", "공연 기록", "멤버"]) {
      await user.click(within(navigation).getByRole("button", { name: new RegExp(screenName) }));
      expect(screen.getByRole("heading", { name: screenName, level: 2 })).toBeInTheDocument();
    }
  });

  it("creates and displays a rehearsal schedule", async () => {
    await renderApp();
    const user = userEvent.setup();
    await user.click(within(screen.getByRole("navigation")).getByRole("button", { name: /합주 일정/ }));
    vi.mocked(window.prompt)
      .mockReturnValueOnce("테스트 합주")
      .mockReturnValueOnce("2026-10-15")
      .mockReturnValueOnce("20:00")
      .mockReturnValueOnce("테스트 스튜디오");
    await user.click(screen.getByRole("button", { name: /새 일정/ }));
    expect(screen.getAllByText("테스트 합주").length).toBeGreaterThan(0);
    expect(localStorage.getItem("scorimo-v2-events")).toContain("테스트 합주");
  });

  it("adds, searches, filters, and changes a song status", async () => {
    await renderApp();
    const user = userEvent.setup();
    await user.click(within(screen.getByRole("navigation")).getByRole("button", { name: /곡 관리/ }));
    vi.mocked(window.prompt)
      .mockReturnValueOnce("테스트 곡")
      .mockReturnValueOnce("테스트 아티스트")
      .mockReturnValueOnce("F")
      .mockReturnValueOnce("128");
    await user.click(screen.getByRole("button", { name: /곡 추가/ }));
    const search = screen.getByPlaceholderText("곡명 또는 아티스트 검색");
    await user.type(search, "테스트 곡");
    expect(screen.getByText("테스트 곡")).toBeInTheDocument();
    const row = screen.getByText("테스트 곡").closest(".song-table");
    expect(row).not.toBeNull();
    await user.click(within(row as HTMLElement).getByText("시작 전"));
    expect(within(row as HTMLElement).getByText("합주 중")).toBeInTheDocument();
  });

  it("stores a PDF score and renders it in the score viewer", async () => {
    await renderApp();
    const user = userEvent.setup();
    await user.click(screen.getByRole("button", { name: /악보실/ }));
    const input = document.querySelector('input[type="file"]') as HTMLInputElement;
    const pdf = new File(["%PDF-1.4 test"], "guitar-score.pdf", { type: "application/pdf" });
    fireEvent.change(input, { target: { files: [pdf] } });
    expect(await screen.findByText("guitar-score.pdf")).toBeInTheDocument();
    const frame = await screen.findByTitle("Square Guitar 악보");
    expect(frame).toHaveAttribute("src", expect.stringContaining("blob:scorimo-score"));
    expect(URL.createObjectURL).toHaveBeenCalled();
    const stored = await getScore("Square::Guitar");
    expect(stored?.fileName).toBe("guitar-score.pdf");
    expect(cloudMocks.upload).toHaveBeenCalledWith("Square::Guitar", pdf);
  });

  it("adds a ledger entry and toggles a member payment", async () => {
    await renderApp();
    const user = userEvent.setup();
    await user.click(screen.getByRole("button", { name: /회비 관리/ }));
    vi.mocked(window.prompt).mockReturnValueOnce("테스트 수입").mockReturnValueOnce("50000");
    await user.click(screen.getByRole("button", { name: /내역 추가/ }));
    expect(screen.getByText("테스트 수입")).toBeInTheDocument();
    const member = screen.getByText("박성호").closest("button");
    expect(member).not.toBeNull();
    expect(within(member as HTMLElement).getByText("미납")).toBeInTheDocument();
    await user.click(member as HTMLElement);
    expect(within(member as HTMLElement).getByText("납부 완료")).toBeInTheDocument();
  });

  it("adds a performance and copies an invitation link", async () => {
    await renderApp();
    const user = userEvent.setup();
    await user.click(screen.getByRole("button", { name: /공연 기록/ }));
    vi.mocked(window.prompt).mockReturnValueOnce("테스트 라이브").mockReturnValueOnce("2026. 10. 10");
    await user.click(screen.getByRole("button", { name: /^공연 추가$/ }));
    expect(screen.getAllByText("테스트 라이브").length).toBeGreaterThan(0);
    await user.click(screen.getByRole("button", { name: /^멤버$/ }));
    await user.click(screen.getByRole("button", { name: /멤버 초대/ }));
    expect(await screen.findByText(/초대 링크를 복사했습니다/)).toBeInTheDocument();
  });

  it("runs the rehearsal controls and global search navigation", async () => {
    await renderApp();
    const user = userEvent.setup();
    await user.click(screen.getByRole("button", { name: "검색" }));
    await user.type(screen.getByPlaceholderText("곡, 일정, 멤버 검색"), "악보");
    const searchModal = document.querySelector(".modal");
    expect(searchModal).not.toBeNull();
    await user.click(within(searchModal as HTMLElement).getByRole("button", { name: /악보실/ }));
    await user.click(screen.getByRole("button", { name: /합주 모드 시작/ }));
    expect(screen.getByText("INTRO")).toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: /동기화 시작/ }));
    expect(screen.getByText("LIVE SYNC")).toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: /NEXT/ }));
    expect(screen.getByText("VERSE 1")).toBeInTheDocument();
  });

  it("shows real upcoming schedules in notifications and marks them read", async () => {
    localStorage.setItem("scorimo-v2-events", JSON.stringify([
      { date: "2099-12-20", title: "실제 합주 알림", time: "19:30", room: "연습실 A", type: "lime" },
    ]));
    await renderApp();
    const user = userEvent.setup();
    await user.click(screen.getByRole("button", { name: "알림" }));
    expect(screen.getByText("실제 합주 알림")).toBeInTheDocument();
    expect(screen.getByText("연습실 A")).toBeInTheDocument();
    await user.click(screen.getByText("실제 합주 알림"));
    expect(screen.getByRole("heading", { name: "합주 일정", level: 2 })).toBeInTheDocument();
    expect(localStorage.getItem("scorimo-v2-read-notifications")).toContain("실제 합주 알림");
  });

  it("calls Supabase for email and Google authentication", async () => {
    authMocks.user = null;
    render(<App />);
    const user = userEvent.setup();
    await screen.findByRole("heading", { name: "다시 만나서 반가워요." });
    await user.type(screen.getByPlaceholderText("name@example.com"), "member@example.com");
    await user.type(screen.getByPlaceholderText("6자 이상 입력"), "password123");
    await user.click(screen.getByRole("button", { name: /^로그인/ }));
    expect(authMocks.signInWithPassword).toHaveBeenCalledWith({
      email: "member@example.com",
      password: "password123",
    });
    await user.click(screen.getByRole("button", { name: /Google 계정으로 계속/ }));
    expect(authMocks.signInWithOAuth).toHaveBeenCalledWith({
      provider: "google",
      options: { redirectTo: window.location.origin },
    });
  });
});
