import { useEffect, useRef, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "./lib/supabase";
import { getScore, getScoreIds, removeScore, saveScore, type StoredScore } from "./lib/scoreStorage";
import { deleteCloudScore, getCloudScore, getCloudScoreIds, uploadCloudScore } from "./lib/scoreCloud";

type IconName =
  | "home"
  | "calendar"
  | "music"
  | "score"
  | "wallet"
  | "stage"
  | "users"
  | "plus"
  | "chevron"
  | "pin"
  | "clock"
  | "play"
  | "more"
  | "check"
  | "upload"
  | "bell"
  | "search"
  | "close"
  | "arrow"
  | "mic";

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    home: <><path d="m3 10 9-7 9 7" /><path d="M5 9v11h14V9M9 20v-6h6v6" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
    music: <><path d="M9 18V5l10-2v13" /><circle cx="6" cy="18" r="3" /><circle cx="16" cy="16" r="3" /></>,
    score: <><path d="M5 3h14v18H5zM8 8h8M8 12h8M8 16h5" /></>,
    wallet: <><path d="M3 7h18v13H3zM3 7l3-4h12l3 4M16 13h5" /></>,
    stage: <><path d="M4 4h16v14H4zM8 22l4-4 4 4M8 8l2 2 4-4 2 2" /></>,
    users: <><circle cx="9" cy="8" r="4" /><path d="M2 21v-2c0-4 3-7 7-7s7 3 7 7v2M16 4c3 0 5 2 5 5s-2 5-5 5M18 14c2 1 4 3 4 7" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    chevron: <path d="m9 6 6 6-6 6" />,
    pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    play: <path d="m9 7 8 5-8 5Z" />,
    more: <><circle cx="5" cy="12" r="1" fill="currentColor" /><circle cx="12" cy="12" r="1" fill="currentColor" /><circle cx="19" cy="12" r="1" fill="currentColor" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    upload: <><path d="M12 16V4m0 0L7 9m5-5 5 5M4 15v5h16v-5" /></>,
    bell: <><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
    search: <><circle cx="10" cy="10" r="7" /><path d="m15 15 6 6" /></>,
    close: <path d="M6 6l12 12M18 6 6 18" />,
    arrow: <path d="m15 18-6-6 6-6" />,
    mic: <><rect x="9" y="3" width="6" height="12" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3M8 21h8" /></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

const navItems: { id: string; label: string; icon: IconName }[] = [
  { id: "home", label: "홈", icon: "home" },
  { id: "schedule", label: "합주 일정", icon: "calendar" },
  { id: "songs", label: "곡 관리", icon: "music" },
  { id: "scores", label: "악보실", icon: "score" },
  { id: "fees", label: "회비 관리", icon: "wallet" },
  { id: "performances", label: "공연 기록", icon: "stage" },
  { id: "members", label: "멤버", icon: "users" },
];

type Song = { title: string; artist: string; key: string; bpm: number; status: string; progress: number };
type BandMember = { name: string; role: string; part: string; initials: string; color: string };
const emptySongs: Song[] = [];
const emptyMembers: BandMember[] = [];

function notify(message: string) {
  window.dispatchEvent(new CustomEvent("scorimo-notify", { detail: message }));
}

function useStoredState<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : initialValue;
    } catch {
      return initialValue;
    }
  });
  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);
  return [value, setValue] as const;
}

function Pill({ children, tone = "default" }: { children: React.ReactNode; tone?: string }) {
  return <span className={`pill ${tone}`}>{children}</span>;
}

function Avatar({ initials, color = "coral" }: { initials: string; color?: string }) {
  return <span className={`avatar ${color}`}>{initials}</span>;
}

function Header({ active, onSearch, onProfile, onNavigate, user }: { active: string; onSearch: () => void; onProfile: () => void; onNavigate: (id: string) => void; user: User }) {
  const current = navItems.find((item) => item.id === active)?.label || "홈";
  const displayName = user.user_metadata.full_name || user.user_metadata.name || user.email?.split("@")[0] || "멤버";
  const initials = displayName.slice(0, 2).toUpperCase();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [readNotifications, setReadNotifications] = useStoredState<string[]>("scorimo-v2-read-notifications", []);
  let storedEvents: Array<{ date: string; title: string; time: string; room: string }> = [];
  try {
    storedEvents = JSON.parse(localStorage.getItem("scorimo-v2-events") || "[]");
  } catch {
    storedEvents = [];
  }
  const today = new Date();
  const upcomingEvents = storedEvents
    .filter((event) => new Date(`${event.date}T23:59:59`) >= today)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 5);
  const eventId = (event: { date: string; title: string }) => `${event.date}-${event.title}`;
  const unreadCount = upcomingEvents.filter((event) => !readNotifications.includes(eventId(event))).length;
  const markAllRead = () => setReadNotifications(upcomingEvents.map(eventId));
  return (
    <header className="topbar">
      <div>
        <p className="eyebrow">SCORIMO BAND</p>
        <h1>{current}</h1>
      </div>
      <div className="header-actions">
        <button className="icon-button" onClick={onSearch} aria-label="검색"><Icon name="search" /></button>
        <div className="notification-wrap">
          <button className="icon-button notification" onClick={() => setNotificationsOpen(!notificationsOpen)} aria-label="알림"><Icon name="bell" />{unreadCount > 0 && <span />}</button>
          {notificationsOpen && <div className="notification-panel"><div className="notification-head"><div><p className="section-kicker">NOTIFICATIONS</p><strong>알림</strong></div>{unreadCount > 0 && <button onClick={markAllRead}>모두 읽음</button>}</div>{upcomingEvents.length ? <div className="notification-list">{upcomingEvents.map((event) => { const unread = !readNotifications.includes(eventId(event)); return <button className={unread ? "unread" : ""} key={eventId(event)} onClick={() => { setReadNotifications(current => Array.from(new Set([...current,eventId(event)]))); setNotificationsOpen(false); onNavigate("schedule"); }}><span><Icon name="calendar" size={16}/></span><div><strong>{event.title}</strong><p>{event.date} · {event.time}</p><small>{event.room}</small></div>{unread && <i/>}</button>})}</div> : <div className="notification-empty"><Icon name="bell" size={25}/><strong>새 알림이 없습니다.</strong><span>합주 일정을 등록하면 여기에 표시됩니다.</span></div>}</div>}
        </div>
        <button className="profile" onClick={onProfile}><Avatar initials={initials} /><div><strong>{displayName}</strong><span>{user.email || "Google 계정"} · 로그아웃</span></div></button>
      </div>
    </header>
  );
}

function Sidebar({ active, setActive, band, setBand, onCreate }: { active: string; setActive: (id: string) => void; band: string; setBand: (name: string) => void; onCreate: () => void }) {
  const [switching, setSwitching] = useState(false);
  return (
    <aside className="sidebar">
      <button className="brand" onClick={() => setActive("home")}><span className="brand-mark"><i /><i /><i /><i /></span><strong>SCORIMO</strong><small>BAND</small></button>
      <div className="band-switch">
        <button className="band-current" onClick={() => setSwitching(!switching)}>
          <span className="band-logo">TR</span><span><small>현재 밴드</small><strong>{band}</strong></span><Icon name="chevron" size={16} />
        </button>
        {switching && (
          <div className="band-menu">
            <button onClick={() => setSwitching(false)}>{band}<Icon name="check" size={15} /></button>
            <button onClick={() => { onCreate(); setSwitching(false); }}><Icon name="plus" size={15} /> 새 밴드 만들기</button>
          </div>
        )}
      </div>
      <nav>
        <p className="nav-label">BAND SPACE</p>
        {navItems.map((item) => (
          <button key={item.id} className={active === item.id ? "active" : ""} onClick={() => setActive(item.id)}>
            <Icon name={item.icon} /><span>{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="sidebar-bottom">
        <a className="source-download" href="https://github.com/chaeun-son/scorimo-band-download/raw/refs/heads/main/scorimo-band-all-in-one.zip"><Icon name="upload" size={16}/><span>전체 프로젝트 한 번에 다운로드</span></a>
        <button className="settings" onClick={() => notify("도움말: 왼쪽 메뉴에서 기능을 선택하고, 각 화면의 추가 버튼으로 데이터를 등록하세요.")}><span>?</span> 도움말 및 설정</button>
      </div>
    </aside>
  );
}

function Home({ navigate, band }: { navigate: (id: string) => void; band: string }) {
  const today = new Intl.DateTimeFormat("ko-KR", { year: "numeric", month: "long", day: "numeric", weekday: "long" }).format(new Date());
  const storedSongs = JSON.parse(localStorage.getItem("scorimo-v2-songs") || "[]") as Song[];
  const storedEvents = JSON.parse(localStorage.getItem("scorimo-v2-events") || "[]") as Array<{ date: string }>;
  const futureEvents = storedEvents.filter((event) => new Date(`${event.date}T23:59:59`) >= new Date());
  return (
    <div className="page">
      <section className="welcome">
        <div><Pill tone="lime">{today}</Pill><h2>밴드 운영을<br />시작해 볼까요?</h2><p>{band === "밴드를 만들어 주세요" ? "먼저 밴드를 만들고 멤버를 초대하세요." : `${band}의 일정과 연습곡을 관리하세요.`}</p></div>
        <div className="wave-art"><span className="disc"><i /></span><div className="wave">{[22,42,31,62,84,48,72,36,56,25,64,40,78,51,28].map((h, i) => <i key={i} style={{ height: `${h}%` }} />)}</div></div>
      </section>

      <div className="dashboard-grid">
        <section className="card setup-card"><Icon name="calendar" size={25}/><div><p className="section-kicker">REHEARSALS</p><h3>{futureEvents.length ? `예정된 일정 ${futureEvents.length}개` : "등록된 합주 일정이 없습니다"}</h3><p>실제 합주 날짜, 시간과 장소를 등록하세요.</p></div><button className="primary small" onClick={() => navigate("schedule")}>{futureEvents.length ? "일정 보기" : "첫 일정 등록"}</button></section>
        <section className="card setup-card"><Icon name="music" size={25}/><div><p className="section-kicker">TRACKS</p><h3>{storedSongs.length ? `연습곡 ${storedSongs.length}곡` : "등록된 연습곡이 없습니다"}</h3><p>곡을 추가한 후 파트별 PDF 악보를 연결하세요.</p></div><button className="primary small" onClick={() => navigate("songs")}>{storedSongs.length ? "곡 관리" : "첫 곡 추가"}</button></section>
      </div>
      <section className="card getting-started"><p className="section-kicker">GETTING STARTED</p><h3>실제 밴드 운영을 위한 시작 순서</h3><div><button onClick={() => navigate("members")}><strong>1</strong><span>멤버 초대<small>초대 링크를 공유하세요.</small></span></button><button onClick={() => navigate("schedule")}><strong>2</strong><span>합주 일정 등록<small>날짜와 장소를 정하세요.</small></span></button><button onClick={() => navigate("songs")}><strong>3</strong><span>연습곡 추가<small>Key와 BPM을 입력하세요.</small></span></button><button onClick={() => navigate("scores")}><strong>4</strong><span>악보 업로드<small>파트별 PDF를 등록하세요.</small></span></button></div></section>
    </div>
  );
}

function Schedule() {
  const now = new Date();
  const [viewDate, setViewDate] = useState(new Date(now.getFullYear(), now.getMonth(), 1));
  const [events, setEvents] = useStoredState<Array<{ date: string; title: string; time: string; room: string; type: string }>>("scorimo-v2-events", []);
  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const firstWeekday = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = Array.from({ length: 42 }, (_, index) => index - firstWeekday + 1);
  const dateValue = (day: number) => `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  const addEvent = () => {
    const title = window.prompt("일정 이름을 입력하세요.", "정기 합주");
    if (!title) return;
    const defaultDate = new Date().toISOString().slice(0, 10);
    const date = window.prompt("날짜를 입력하세요. (YYYY-MM-DD)", defaultDate) || "";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(new Date(`${date}T00:00:00`).getTime())) return notify("올바른 날짜를 입력해 주세요.");
    const time = window.prompt("시작 시간을 입력하세요.", "19:00") || "19:00";
    const room = window.prompt("장소를 입력하세요.", "합주실") || "장소 미정";
    setEvents((current) => [...current, { date, title, time, room, type: "lime" }].sort((a, b) => a.date.localeCompare(b.date)));
    const selectedDate = new Date(`${date}T00:00:00`);
    setViewDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1));
    notify(`${title} 일정이 추가되었습니다.`);
  };
  const showEvent = (title: string, time: string, room: string) => notify(`${title} · ${time} · ${room}`);
  return <div className="page"><div className="page-title"><div><p className="eyebrow">REHEARSAL CALENDAR</p><h2>합주 일정</h2><p>멤버들과 일정을 조율하고 연습곡을 준비하세요.</p></div><button className="primary" onClick={addEvent}><Icon name="plus" /> 새 일정</button></div>
    <div className="schedule-layout"><section className="card calendar-card"><div className="calendar-header"><button onClick={() => setViewDate(new Date(year, month - 1, 1))}><Icon name="arrow" /></button><h3>{year}년 {month + 1}월</h3><button className="flip" onClick={() => setViewDate(new Date(year, month + 1, 1))}><Icon name="arrow" /></button></div><div className="weekdays">{["일","월","화","수","목","금","토"].map(d => <span key={d}>{d}</span>)}</div><div className="calendar-grid">{cells.map((day, i) => { const valid = day > 0 && day <= daysInMonth; const date = valid ? dateValue(day) : ""; const event = events.find(e => e.date === date); const today = date === new Date().toISOString().slice(0,10); return <button key={i} disabled={!valid} onClick={() => event ? showEvent(event.title, event.time, event.room) : notify(`${month + 1}월 ${day}일에는 등록된 일정이 없습니다.`)} className={`${!valid ? "muted" : ""} ${today ? "today" : ""}`}><span>{valid ? day : ""}</span>{event && <i className={event.type}>{event.title}</i>}</button>})}</div></section>
    <aside className="card upcoming-list"><p className="section-kicker">UPCOMING</p><h3>다가오는 일정</h3>{events.length ? events.filter(e => new Date(`${e.date}T23:59:59`) >= new Date()).map((e) => <button className="event-item" onClick={() => showEvent(e.title, e.time, e.room)} key={`${e.date}-${e.title}`}><div><strong>{Number(e.date.slice(-2))}</strong><small>{Number(e.date.slice(5,7))}월</small></div><span><Pill tone={e.type}>{e.title}</Pill><h4>{e.title}</h4><p>{e.time} · {e.room}</p></span><Icon name="chevron" size={16} /></button>) : <div className="mini-empty">예정된 일정이 없습니다.</div>}</aside></div></div>;
}

function Songs({ navigate }: { navigate: (id: string) => void }) {
  const [filter, setFilter] = useState("전체");
  const [query, setQuery] = useState("");
  const [songList, setSongList] = useStoredState<Song[]>("scorimo-v2-songs", emptySongs);
  const addSong = () => {
    const title = window.prompt("곡명을 입력하세요.");
    if (!title) return;
    const artist = window.prompt("아티스트를 입력하세요.", "아티스트 미정") || "아티스트 미정";
    const key = window.prompt("Key를 입력하세요.", "C") || "C";
    const bpm = Number(window.prompt("BPM을 입력하세요.", "120")) || 120;
    setSongList((current) => [...current, { title, artist, key, bpm, status: "시작 전", progress: 0 }]);
    notify(`${title} 곡이 추가되었습니다.`);
  };
  const changeStatus = (index: number) => {
    const order = ["시작 전", "합주 중", "완료", "보관"];
    setSongList((current) => current.map((song, i) => i === index ? { ...song, status: order[(order.indexOf(song.status) + 1) % order.length] } : song));
    notify("곡 진행 상태를 변경했습니다.");
  };
  const visibleSongs = songList.filter((song) => (filter === "전체" || (filter === "연습 중" ? song.status === "합주 중" : song.status === filter)) && `${song.title} ${song.artist}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="page"><div className="page-title"><div><p className="eyebrow">TRACK LIBRARY</p><h2>곡 관리</h2><p>연습곡과 공연 세트리스트를 한곳에서 관리하세요.</p></div><button className="primary" onClick={addSong}><Icon name="plus" /> 곡 추가</button></div>
    <div className="toolbar"><div className="tabs">{["전체","연습 중","완료","보관"].map(x => <button className={filter === x ? "active" : ""} onClick={() => setFilter(x)} key={x}>{x} <span>{x === "전체" ? songList.length : songList.filter(s => x === "연습 중" ? s.status === "합주 중" : s.status === x).length}</span></button>)}</div><label className="search-box"><Icon name="search" size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="곡명 또는 아티스트 검색" /></label></div>
    <section className="card table-card"><div className="song-table head"><span>순서</span><span>곡 정보</span><span>진행 상태</span><span>Key / BPM</span><span>악보</span><span /></div>{visibleSongs.map((song) => { const i = songList.indexOf(song); return <div className="song-table" key={song.title}><span className="drag">⠿ <b>{String(i+1).padStart(2,"0")}</b></span><span className="song-cell"><i><Icon name="music" size={18} /></i><em><strong>{song.title}</strong><small>{song.artist}</small></em></span><button className="status-button" onClick={() => changeStatus(i)}><Pill tone={song.status === "완료" ? "green" : song.status === "시작 전" ? "default" : "orange"}>{song.status}</Pill></button><span className="song-key">{song.key} <small>{song.bpm} BPM</small></span><button className="score-count" onClick={() => navigate("scores")}><Icon name="score" size={17} /> {i === 3 ? 2 : 5}/5</button><button className="icon-button" onClick={() => changeStatus(i)}><Icon name="more" /></button></div>})}</section></div>;
}

function Scores({ navigate }: { navigate: (id: string) => void }) {
  const [songList] = useStoredState<Song[]>("scorimo-v2-songs", emptySongs);
  const [selected, setSelected] = useState(0);
  const [part, setPart] = useState(1);
  const [query, setQuery] = useState("");
  const [uploaded, setUploaded] = useState<string[]>([]);
  const [currentScore, setCurrentScore] = useState<StoredScore | null>(null);
  const [pdfUrl, setPdfUrl] = useState("");
  const [scoreLoading, setScoreLoading] = useState(true);
  const [cloudStatus, setCloudStatus] = useState<"connecting" | "synced" | "offline">("connecting");
  const fileRef = useRef<HTMLInputElement>(null);
  const parts = ["Vocal", "Guitar", "Keyboard", "Bass", "Drums"];
  const currentSong = songList[selected];
  const scoreId = currentSong ? `${currentSong.title}::${parts[part]}` : "";

  useEffect(() => {
    getScoreIds().then(setUploaded).catch(() => notify("저장된 악보 목록을 불러오지 못했습니다."));
    getCloudScoreIds()
      .then((ids) => {
        setUploaded((current) => Array.from(new Set([...current, ...ids])));
        setCloudStatus("synced");
      })
      .catch(() => setCloudStatus("offline"));
  }, []);

  useEffect(() => {
    if (!scoreId) {
      setCurrentScore(null);
      setPdfUrl("");
      setScoreLoading(false);
      return;
    }
    let objectUrl = "";
    setScoreLoading(true);
    getScore(scoreId)
      .then((score) => {
        setCurrentScore(score || null);
        if (score) {
          objectUrl = URL.createObjectURL(score.file);
          setPdfUrl(objectUrl);
        } else {
          setPdfUrl("");
        }
      })
      .catch(() => notify("악보를 불러오지 못했습니다."))
      .finally(() => setScoreLoading(false));
    getCloudScore(scoreId)
      .then(async (cloudScore) => {
        setCloudStatus("synced");
        if (!cloudScore) return;
        const cloudFile = new File([cloudScore.file], cloudScore.fileName, { type: "application/pdf" });
        await saveScore(scoreId, cloudFile);
        if (objectUrl) URL.revokeObjectURL(objectUrl);
        objectUrl = URL.createObjectURL(cloudScore.file);
        setCurrentScore(cloudScore);
        setPdfUrl(objectUrl);
        setUploaded((current) => Array.from(new Set([...current, scoreId])));
      })
      .catch(() => setCloudStatus("offline"));
    return () => {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [scoreId]);

  const uploadScore = async (file: File) => {
    if (!scoreId) return notify("먼저 곡 관리에서 연습곡을 추가해 주세요.");
    if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
      notify("PDF 형식의 악보만 업로드할 수 있습니다.");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      notify("악보 파일은 20MB 이하만 등록할 수 있습니다.");
      return;
    }
    try {
      await saveScore(scoreId, file);
      const stored = await getScore(scoreId);
      if (!stored) throw new Error("Saved score not found");
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
      setCurrentScore(stored);
      setPdfUrl(URL.createObjectURL(stored.file));
      setUploaded((current) => Array.from(new Set([...current, scoreId])));
      try {
        await uploadCloudScore(scoreId, file);
        setCloudStatus("synced");
        notify(`${file.name} 악보가 클라우드에 저장되어 모든 기기에서 표시됩니다.`);
      } catch {
        setCloudStatus("offline");
        notify(`${file.name} 악보는 이 기기에 저장되었습니다. 클라우드 서버 배포 후 자동 공유됩니다.`);
      }
    } catch {
      notify("악보 저장에 실패했습니다. 브라우저 저장 공간을 확인해 주세요.");
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const deleteScore = async () => {
    if (!currentScore || !window.confirm(`${currentScore.fileName} 악보를 삭제할까요?`)) return;
    await removeScore(scoreId);
    try {
      await deleteCloudScore(scoreId);
      setCloudStatus("synced");
    } catch {
      setCloudStatus("offline");
    }
    if (pdfUrl) URL.revokeObjectURL(pdfUrl);
    setCurrentScore(null);
    setPdfUrl("");
    setUploaded((current) => current.filter((id) => id !== scoreId));
    notify("악보가 삭제되었습니다.");
  };

  if (!currentSong) {
    return <div className="page"><div className="page-title"><div><p className="eyebrow">SCORE ROOM</p><h2>악보실</h2><p>곡을 추가한 후 파트별 악보를 등록하세요.</p></div></div><div className="card page-empty"><Icon name="score" size={36}/><h3>등록된 곡이 없습니다.</h3><p>가짜 예시 곡은 표시하지 않습니다. 실제 연습곡을 먼저 추가해 주세요.</p><button className="primary" onClick={() => navigate("songs")}><Icon name="plus" size={16}/> 첫 곡 추가하기</button></div></div>;
  }

  return <div className="page"><div className="page-title"><div><p className="eyebrow">SCORE ROOM</p><h2>악보실</h2><p>내 파트 악보를 준비하고 합주 동기화 상태를 확인하세요.</p></div><button className="primary" onClick={() => navigate("live")}><Icon name="play" /> 합주 모드 시작</button></div>
    <div className="score-layout"><aside className="card score-songs"><label className="search-box"><Icon name="search" size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="악보 검색" /></label>{songList.filter(s => `${s.title} ${s.artist}`.toLowerCase().includes(query.toLowerCase())).map((s) => { const i = songList.indexOf(s); return <button className={selected === i ? "active" : ""} onClick={() => setSelected(i)} key={s.title}><span>{String(i+1).padStart(2,"0")}</span><div><strong>{s.title}</strong><small>{s.artist}</small></div><Icon name="chevron" size={16} /></button>})}</aside>
    <section className="card score-detail"><div className="score-title"><div><span className="score-statuses"><Pill tone={currentScore ? "green" : "orange"}>{currentScore ? "악보 등록됨" : "악보 준비 필요"}</Pill><Pill tone={cloudStatus === "synced" ? "lime" : "default"}>{cloudStatus === "synced" ? "CLOUD SYNC" : cloudStatus === "connecting" ? "연결 중" : "오프라인 저장"}</Pill></span><h3>{currentSong.title}</h3><p>{currentSong.artist} · Key {currentSong.key} · {currentSong.bpm} BPM</p></div><button className="outline" onClick={() => fileRef.current?.click()}><Icon name="upload" size={17} /> {currentScore ? "악보 교체" : "내 악보 업로드"}</button><input ref={fileRef} className="hidden-file" type="file" accept="application/pdf,.pdf" onChange={(event) => { const file = event.target.files?.[0]; if (file) uploadScore(file); }} /></div><div className="part-tabs">{parts.map((p,i) => <button className={i === part ? "active" : ""} onClick={() => setPart(i)} key={p}>{p}<span>{i === part ? "내 파트" : uploaded.includes(`${currentSong.title}::${p}`) ? "업로드됨" : "미등록"}</span></button>)}</div><div className="score-preview">{scoreLoading ? <div className="score-empty"><strong>악보를 불러오는 중</strong><span>잠시만 기다려 주세요.</span></div> : pdfUrl && currentScore ? <div className="pdf-viewer"><div className="pdf-toolbar"><span><Icon name="score" size={16}/><strong>{currentScore.fileName}</strong><small>{parts[part]} · {(currentScore.file.size / 1024 / 1024).toFixed(1)}MB</small></span><div><a href={pdfUrl} download={currentScore.fileName}>다운로드</a><button onClick={deleteScore}>삭제</button></div></div><iframe title={`${currentSong.title} ${parts[part]} 악보`} src={`${pdfUrl}#toolbar=1&navpanes=0&view=FitH`} /></div> : <div className="score-empty"><Icon name="upload" size={32}/><strong>{parts[part]} 악보가 없습니다.</strong><span>PDF 악보를 업로드하면 이 화면에 바로 표시됩니다.</span><button className="primary" onClick={() => fileRef.current?.click()}>PDF 악보 선택</button></div>}<div className="mapping"><Pill tone={currentScore ? "lime" : "default"}>{currentScore ? "SYNC READY" : "WAITING"}</Pill><h4>진행 지점 매핑</h4><p>{currentScore ? "공통 진행 지점 8개 중 8개가 연결되었습니다." : "악보 등록 후 진행 지점을 연결할 수 있습니다."}</p><div className="map-progress"><i style={{width:currentScore ? "100%" : "0%"}} /></div><small>Intro → Verse 1 → Chorus → Verse 2 → Bridge → Outro</small></div></div></section></div></div>;
}

function Fees() {
  const [payments, setPayments] = useStoredState<Array<{name:string;status:boolean}>>("scorimo-v2-payments", []);
  const [ledger, setLedger] = useStoredState<string[][]>("scorimo-v2-ledger", []);
  const addLedger = () => {
    const title = window.prompt("내역명을 입력하세요.");
    if (!title) return;
    const amount = Number(window.prompt("금액을 입력하세요.", "70000"));
    if (!amount) return;
    const isIncome = window.confirm("수입 내역인가요? 취소를 누르면 지출로 기록됩니다.");
    setLedger(current => [[title, "오늘", `${isIncome ? "+" : "-"} ₩${amount.toLocaleString()}`, isIncome ? "in" : "out"], ...current]);
    notify("회비 내역이 추가되었습니다.");
  };
  const paidCount = payments.filter(p => p.status).length;
  const amountOf = (entry: string[]) => Number(entry[2].replace(/[^0-9]/g, "")) || 0;
  const income = ledger.filter(x => x[3] === "in").reduce((sum, x) => sum + amountOf(x), 0);
  const expense = ledger.filter(x => x[3] === "out").reduce((sum, x) => sum + amountOf(x), 0);
  const currentMonth = new Date().getMonth() + 1;
  return <div className="page"><div className="page-title"><div><p className="eyebrow">BAND FINANCE</p><h2>회비 관리</h2><p>회비 납부와 밴드 운영 지출을 투명하게 기록하세요.</p></div><button className="primary" onClick={addLedger}><Icon name="plus" /> 내역 추가</button></div>
    <div className="stat-grid"><div className="card finance-stat"><span>현재 잔액</span><strong>₩ {(income-expense).toLocaleString()}</strong><small>직접 등록한 장부 기준</small></div><div className="card finance-stat"><span>{currentMonth}월 수입</span><strong>₩ {income.toLocaleString()}</strong><small>{ledger.filter(x=>x[3]==="in").length}건</small></div><div className="card finance-stat"><span>{currentMonth}월 지출</span><strong>₩ {expense.toLocaleString()}</strong><small>{ledger.filter(x=>x[3]==="out").length}건</small></div></div>
    <div className="finance-grid"><section className="card"><div className="card-head"><div><p className="section-kicker">MONTHLY DUES</p><h3>{currentMonth}월 회비 납부 현황</h3></div><Pill tone="lime">{payments.length ? Math.round(paidCount / payments.length * 100) : 0}% 완료</Pill></div><div className="payment-list">{payments.length ? payments.map((p,i)=><button onClick={() => { setPayments(current => current.map((item,index) => index === i ? {...item,status:!item.status} : item)); notify(`${p.name}님의 납부 상태를 변경했습니다.`); }} key={p.name}><Avatar initials={p.name.slice(0,2)} /><span><strong>{p.name}</strong><small>밴드 멤버</small></span><b className={p.status ? "paid" : "unpaid"}>{p.status ? "납부 완료" : "미납"}</b><strong>금액 미설정</strong></button>) : <div className="mini-empty">멤버와 월 회비가 아직 설정되지 않았습니다.</div>}</div></section><section className="card ledger"><div className="card-head"><div><p className="section-kicker">RECENT LEDGER</p><h3>최근 입출금</h3></div></div>{ledger.length ? ledger.map((x,i)=><button className="ledger-row" onClick={() => notify(`${x[0]} · ${x[2]}`)} key={`${x[0]}-${i}`}><span className={x[3]}>{x[3]==="in" ? "IN" : "OUT"}</span><p><strong>{x[0]}</strong><small>{x[1]}</small></p><b className={x[3]}>{x[2]}</b></button>) : <div className="mini-empty">등록된 수입·지출 내역이 없습니다.</div>}</section></div></div>;
}

function Performances() {
  const [archives, setArchives] = useStoredState<string[][]>("scorimo-v2-performances", []);
  const addPerformance = () => {
    const title = window.prompt("공연 이름을 입력하세요.");
    if (!title) return;
    const date = window.prompt("공연 날짜를 입력하세요.", new Date().toISOString().slice(0, 10)) || "날짜 미정";
    setArchives(current => [[title.toUpperCase(), date, title], ...current]);
    notify(`${title} 공연 기록이 추가되었습니다.`);
  };
  return <div className="page"><div className="page-title"><div><p className="eyebrow">BAND ARCHIVE</p><h2>공연 기록</h2><p>함께 만든 무대와 순간들을 차곡차곡 남겨보세요.</p></div><button className="primary" onClick={addPerformance}><Icon name="plus" /> 공연 추가</button></div>
    {archives.length ? <><div className="archive-title"><h3>공연 기록</h3><span>총 {archives.length}개</span></div><div className="archive-grid">{archives.map((x,i)=><button className="card archive-card" onClick={() => notify(`${x[2]} · ${x[1]}`)} key={`${x[0]}-${i}`}><div className={`archive-cover cover-${i%3}`}><Icon name="mic" size={34}/><strong>{x[0]}</strong></div><span>{x[1]}</span><h4>{x[2]}</h4><p>사진과 영상 링크를 추가할 수 있습니다.</p></button>)}</div></> : <div className="card page-empty"><Icon name="stage" size={36}/><h3>공연 기록이 없습니다.</h3><p>실제 공연 일정과 활동 기록을 추가하세요.</p><button className="primary" onClick={addPerformance}><Icon name="plus" size={16}/> 첫 공연 추가</button></div>}</div>;
}

function Members() {
  const [members, setMembers] = useStoredState<BandMember[]>("scorimo-v2-members", emptyMembers);
  const invite = async () => {
    const link = `${window.location.origin}?invite=tuesday-record`;
    await navigator.clipboard.writeText(link).catch(() => undefined);
    notify("초대 링크를 복사했습니다. 원하는 메신저에 붙여넣어 주세요.");
  };
  const changeRole = (index: number) => {
    const roles = ["회원", "운영진", "밴드장"];
    setMembers(current => current.map((member,i) => i === index ? {...member,role:roles[(roles.indexOf(member.role)+1)%roles.length]} : member));
    notify("멤버 권한을 변경했습니다.");
  };
  return <div className="page"><div className="page-title"><div><p className="eyebrow">BAND MEMBERS</p><h2>멤버</h2><p>파트와 권한을 관리하고 새로운 멤버를 초대하세요.</p></div><button className="primary" onClick={invite}><Icon name="plus" /> 멤버 초대</button></div>{members.length ? <div className="member-grid">{members.map((m,i)=><article className="card member-card" key={m.name}><div className="member-top"><Avatar initials={m.initials} color={m.color}/><button className="icon-button" onClick={() => changeRole(i)}><Icon name="more"/></button></div><h3>{m.name}</h3><Pill tone={i===0 ? "lime" : "default"}>{m.role}</Pill><div className="instrument"><Icon name={i === 0 ? "mic" : "music"} /><span><small>MAIN PART</small><strong>{m.part}</strong></span></div><div className="member-footer"><span>등록된 멤버</span><strong>활동 중</strong></div></article>)}</div> : <div className="card page-empty"><Icon name="users" size={36}/><h3>등록된 멤버가 없습니다.</h3><p>초대 링크를 복사해 실제 밴드 멤버에게 공유하세요.</p><button className="primary" onClick={invite}><Icon name="plus" size={16}/> 초대 링크 복사</button></div>}</div>;
}

function LiveMode({ onExit }: { onExit: () => void }) {
  const [songList] = useStoredState<Song[]>("scorimo-v2-songs", emptySongs);
  const liveSong = songList[0];
  const [page, setPage] = useState(1);
  const [playing, setPlaying] = useState(false);
  const [role, setRole] = useState<"host" | "player">("host");
  const [lastSync, setLastSync] = useState("대기 중");
  const channelRef = useRef<BroadcastChannel | null>(null);
  const sessionId = "TR-0322";

  useEffect(() => {
    const applyRemoteState = (state: { page: number; playing: boolean }) => {
      if (role !== "player") return;
      setPage(state.page);
      setPlaying(state.playing);
      setLastSync("방금 동기화됨");
    };
    if ("BroadcastChannel" in window) {
      const channel = new BroadcastChannel(`scorimo-session-${sessionId}`);
      channelRef.current = channel;
      channel.onmessage = (event) => applyRemoteState(event.data);
      return () => channel.close();
    }
    const onStorage = (event: StorageEvent) => {
      if (event.key === `scorimo-session-${sessionId}` && event.newValue) applyRemoteState(JSON.parse(event.newValue));
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [role]);

  useEffect(() => {
    if (role !== "host") return;
    const state = { page, playing, sentAt: Date.now() };
    channelRef.current?.postMessage(state);
    localStorage.setItem(`scorimo-session-${sessionId}`, JSON.stringify(state));
    setLastSync(playing ? "실시간 전송 중" : "동기화 준비");
  }, [page, playing, role]);

  const changePage = (nextPage: number) => {
    if (role === "host") setPage(Math.min(4, Math.max(1, nextPage)));
  };

  return <div className="live-mode"><header><div><button className="live-exit" onClick={onExit}><Icon name="close"/> 종료</button><span className={`live-status ${playing ? "on" : ""}`}><i/> {playing ? "LIVE SYNC" : "READY"}</span></div><div className="live-song"><strong>{liveSong?.title || "합주 세션"}</strong><span>{liveSong ? `${liveSong.artist} · Key ${liveSong.key} · ${liveSong.bpm} BPM` : "곡 관리에서 연습곡을 추가하세요"}</span></div><div className="connected"><div className="role-switch"><button className={role === "host" ? "active" : ""} onClick={() => setRole("host")}>진행자</button><button className={role === "player" ? "active" : ""} onClick={() => setRole("player")}>연주자</button></div><strong>{sessionId} · {lastSync}</strong></div></header>
    <main><div className="live-side"><p>현재 진행</p><strong>{page === 1 ? "INTRO" : page === 2 ? "VERSE 1" : page === 3 ? "CHORUS" : "VERSE 2"}</strong><span>선택 파트 · {page} / 4 page</span>{role === "player" && <span className="follow-label"><i/> 진행자를 따라가는 중</span>}</div><div className="live-paper"><p>{liveSong?.title.toUpperCase() || "NO SCORE SELECTED"}</p><small>{liveSong ? `KEY ${liveSong.key}` : "ADD A PRACTICE TRACK FIRST"}</small><div className="live-staff">{Array.from({length:36},(_,i)=><i key={i} className={i%7===0 ? "note" : ""}/>)}</div><b>{page}</b></div><aside><p>NEXT POINT</p><strong>{page < 4 ? ["VERSE 1","CHORUS","VERSE 2","OUTRO"][page-1] : "END"}</strong><span>{role === "host" ? "현재 기기가 진행자입니다." : "진행자 화면을 따라갑니다."}</span><span>세션 코드: {sessionId}</span></aside></main>
    <footer className={role === "player" ? "player-controls" : ""}><button disabled={role === "player"} onClick={()=>changePage(page-1)}><Icon name="arrow"/> PREV</button><button className={`sync-button ${playing ? "active" : ""}`} disabled={role === "player"} onClick={()=>setPlaying(!playing)}><Icon name={playing ? "close" : "play"} size={25}/>{role === "player" ? "진행자 화면 동기화 중" : playing ? "동기화 일시정지" : "합주 동기화 시작"}</button><button disabled={role === "player"} onClick={()=>changePage(page+1)}>NEXT <span className="flip"><Icon name="arrow"/></span></button></footer></div>;
}

function Modal({ type, onClose, onDone, onNavigate }: { type: string; onClose: () => void; onDone: (name: string) => void; onNavigate: (id: string) => void }) {
  const isSearch = type === "search";
  const [query, setQuery] = useState("");
  const [bandName, setBandName] = useState("");
  const results = navItems.filter(item => item.label.includes(query) || !query);
  return <div className="modal-backdrop" onMouseDown={onClose}><div className={`modal ${isSearch ? "search-modal" : ""}`} onMouseDown={(e)=>e.stopPropagation()}><button className="modal-close" onClick={onClose}><Icon name="close"/></button>{isSearch ? <><p className="eyebrow">QUICK SEARCH</p><h3>무엇을 찾고 있나요?</h3><label className="big-search"><Icon name="search"/><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="곡, 일정, 멤버 검색" /></label><div className="quick-links"><span>{query ? "검색 결과" : "빠른 이동"}</span>{results.map(x=><button onClick={() => { onNavigate(x.id); onClose(); }} key={x.id}><Icon name={x.icon}/>{x.label}</button>)}</div></> : <><p className="eyebrow">CREATE NEW BAND</p><h3>새로운 밴드 만들기</h3><p>밴드의 실제 정보를 입력하세요.</p><label>밴드 이름<input value={bandName} onChange={(event) => setBandName(event.target.value)} placeholder="밴드 이름" /></label><label>활동 지역<input placeholder="예: 서울 마포구" /></label><label>밴드 소개<textarea placeholder="우리 밴드를 소개해 주세요." /></label><button className="primary full" disabled={!bandName.trim()} onClick={() => onDone(bandName.trim())}>밴드 만들기 <Icon name="chevron" size={16}/></button></>}</div></div>;
}

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const authenticate = async () => {
    setLoading(true);
    setError("");
    setMessage("");
    const result = mode === "login"
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: email.split("@")[0] },
            emailRedirectTo: window.location.origin,
          },
        });
    if (result.error) setError(result.error.message);
    else if (mode === "signup" && !result.data.session) setMessage("가입 확인 메일을 보냈습니다. 메일의 인증 링크를 눌러주세요.");
    setLoading(false);
  };

  const signInWithGoogle = async () => {
    setLoading(true);
    setError("");
    const { error: oauthError } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: window.location.origin },
    });
    if (oauthError) {
      setError(oauthError.message);
      setLoading(false);
    }
  };

  const resetPassword = async () => {
    if (!email) {
      setError("비밀번호를 재설정할 이메일을 먼저 입력해 주세요.");
      return;
    }
    setLoading(true);
    setError("");
    const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
    if (resetError) setError(resetError.message);
    else setMessage("비밀번호 재설정 메일을 보냈습니다.");
    setLoading(false);
  };

  return <div className="login-screen"><section className="login-visual"><div className="login-brand"><span className="brand-mark"><i/><i/><i/><i/></span><strong>SCORIMO</strong><small>BAND</small></div><div><Pill tone="lime">BAND OPERATING SYSTEM</Pill><h1>함께 맞추는 소리,<br/>하나로 이어지는 무대.</h1><p>합주 일정부터 악보 동기화까지.<br/>우리 밴드의 모든 순간을 한곳에서 관리하세요.</p></div><small>SCORIMO BAND · MUSIC COLLABORATION PLATFORM</small></section><main className="login-form"><div><p className="eyebrow">{mode === "login" ? "WELCOME BACK" : "JOIN THE BAND"}</p><h2>{mode === "login" ? "다시 만나서 반가워요." : "음악을 함께 시작해요."}</h2><p>{mode === "login" ? "밴드 활동을 계속하려면 로그인하세요." : "계정을 만들고 내 밴드를 운영해 보세요."}</p><label>이메일<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="name@example.com"/></label><label>비밀번호<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="6자 이상 입력"/></label>{error && <div className="auth-message error">{error}</div>}{message && <div className="auth-message success">{message}</div>}<div className="login-options"><label><input type="checkbox" defaultChecked/> 로그인 유지</label><button onClick={resetPassword}>비밀번호 찾기</button></div><button className="primary full" disabled={loading || !email || password.length < 6} onClick={authenticate}>{loading ? "연결 중..." : mode === "login" ? "로그인" : "이메일로 가입"} <Icon name="chevron" size={16}/></button><div className="or"><span/>또는<span/></div><button className="outline full google-button" disabled={loading} onClick={signInWithGoogle}><b>G</b> Google 계정으로 계속</button><p className="signup">{mode === "login" ? "처음이신가요?" : "이미 계정이 있나요?"} <button onClick={() => { setMode(mode === "login" ? "signup" : "login"); setError(""); setMessage(""); }}>{mode === "login" ? "무료로 시작하기" : "로그인"}</button></p></div></main></div>;
}

export default function App() {
  const [active, setActive] = useState("home");
  const [band, setBand] = useStoredState("scorimo-v2-current-band", "밴드를 만들어 주세요");
  const [modal, setModal] = useState("");
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user || null);
      setAuthReady(true);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
      setAuthReady(true);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const showToast = (event: Event) => {
      setToast((event as CustomEvent<string>).detail);
      window.setTimeout(() => setToast(""), 3200);
    };
    window.addEventListener("scorimo-notify", showToast);
    return () => window.removeEventListener("scorimo-notify", showToast);
  }, []);

  if (!authReady) return <div className="auth-loading"><span className="brand-mark"><i/><i/><i/><i/></span><strong>SCORIMO BAND</strong><small>계정을 확인하고 있습니다.</small></div>;
  if (!user) return <Login />;
  if (active === "live") return <LiveMode onExit={() => setActive("scores")} />;
  const page = active === "home" ? <Home navigate={setActive} band={band}/> : active === "schedule" ? <Schedule/> : active === "songs" ? <Songs navigate={setActive}/> : active === "scores" ? <Scores navigate={setActive}/> : active === "fees" ? <Fees/> : active === "performances" ? <Performances/> : <Members/>;
  return <div className="app-shell"><Sidebar active={active} setActive={setActive} band={band} setBand={setBand} onCreate={()=>setModal("create")}/><div className="main-shell"><Header active={active} user={user} onSearch={()=>setModal("search")} onProfile={()=>supabase.auth.signOut()} onNavigate={setActive}/>{page}</div>{modal && <Modal type={modal} onClose={()=>setModal("")} onNavigate={setActive} onDone={(name)=>{setBand(name);setModal("");notify(`${name} 밴드가 만들어졌습니다.`);}}/>}{toast && <div className="toast"><Icon name="check" size={17}/><span>{toast}</span><button onClick={() => setToast("")}><Icon name="close" size={15}/></button></div>}</div>;
}
