import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { projectId, publicAnonKey } from "../../utils/supabase/info";

const fallbackUrl = `https://${projectId}.supabase.co`;
const defaultStorageKey = `sb-${projectId}-auth-token`;
const scorimoStorageKey = `scorimo-band-${projectId}-auth-token`;
const globalForSupabase = globalThis as typeof globalThis & {
  __scorimoSupabase?: SupabaseClient;
};

if (typeof window !== "undefined") {
  const existingSession = window.localStorage.getItem(defaultStorageKey);
  if (existingSession && !window.localStorage.getItem(scorimoStorageKey)) {
    window.localStorage.setItem(scorimoStorageKey, existingSession);
  }
}

export const supabase =
  globalForSupabase.__scorimoSupabase ??
  createClient(
    import.meta.env.VITE_SUPABASE_URL || fallbackUrl,
    import.meta.env.VITE_SUPABASE_ANON_KEY || publicAnonKey,
    {
      auth: {
        storageKey: scorimoStorageKey,
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    },
  );

globalForSupabase.__scorimoSupabase = supabase;
