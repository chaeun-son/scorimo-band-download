import { supabase } from "./supabase";
import { projectId, publicAnonKey } from "../../utils/supabase/info";

const endpoint = `https://${projectId}.supabase.co/functions/v1/make-server-9ee7c1e7/scores`;

async function headers() {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error("로그인이 필요합니다.");
  return {
    Authorization: `Bearer ${token}`,
    apikey: publicAnonKey,
  };
}

async function responseData(response: Response) {
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "클라우드 악보 요청에 실패했습니다.");
  return data;
}

export async function uploadCloudScore(scoreId: string, file: File) {
  const form = new FormData();
  form.append("scoreId", scoreId);
  form.append("file", file);
  const response = await fetch(endpoint, {
    method: "POST",
    headers: await headers(),
    body: form,
  });
  return responseData(response);
}

export async function getCloudScore(scoreId: string) {
  const response = await fetch(`${endpoint}?scoreId=${encodeURIComponent(scoreId)}`, {
    headers: await headers(),
  });
  const data = await responseData(response);
  if (!data.score) return null;
  const fileResponse = await fetch(data.score.signedUrl);
  if (!fileResponse.ok) throw new Error("클라우드 악보 파일을 내려받지 못했습니다.");
  const blob = await fileResponse.blob();
  return {
    id: scoreId,
    fileName: data.score.fileName,
    file: blob,
    updatedAt: data.score.updatedAt,
  };
}

export async function getCloudScoreIds() {
  const response = await fetch(endpoint, { headers: await headers() });
  const data = await responseData(response);
  return (data.scores || []).map((score: { id: string }) => score.id);
}

export async function deleteCloudScore(scoreId: string) {
  const response = await fetch(`${endpoint}?scoreId=${encodeURIComponent(scoreId)}`, {
    method: "DELETE",
    headers: await headers(),
  });
  return responseData(response);
}
