# SCORIMO BAND 실행 안내

이 ZIP은 이미지나 읽기 전용 문서가 아니라 수정·실행 가능한 전체 React + Vite 소스 프로젝트입니다.

## 가장 쉬운 실행 방법

### Windows

1. Node.js 20 이상을 설치합니다: https://nodejs.org/
2. 압축을 풉니다.
3. `start-windows.bat`을 더블클릭합니다.
4. 터미널에 표시된 `http://localhost:5173` 주소를 브라우저에서 엽니다.

### macOS / Linux

터미널에서 압축을 푼 폴더로 이동한 후 실행합니다.

```bash
chmod +x start-mac-linux.sh
./start-mac-linux.sh
```

## 직접 실행

```bash
corepack enable
pnpm install
pnpm dev
```

## 테스트 및 배포 빌드

```bash
pnpm test
pnpm build
pnpm preview
```

빌드 결과는 `dist/` 폴더에 생성됩니다.

## Supabase 설정

기본 공개 Supabase 프로젝트 설정이 코드에 포함되어 있어 화면과 인증을 실행할 수 있습니다. 별도 프로젝트를 사용하려면 `.env.example`을 `.env.local`로 복사하고 다음 값을 설정합니다.

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
```

`service_role` 키와 비밀번호 같은 비밀값은 브라우저 코드나 `.env` 파일에 넣지 마세요.

`supabase/functions/`에는 서버 함수 소스가 들어 있습니다. 클라우드 악보 API는 해당 함수를 별도로 Supabase에 배포해야 사용할 수 있으며, 배포하지 않아도 앱의 로컬 데이터·IndexedDB 기반 주요 화면과 테스트는 실행됩니다.

## 주요 파일

- `src/App.tsx`: 전체 화면과 주요 기능
- `src/index.css`: 전체 디자인
- `src/lib/scoreStorage.ts`: IndexedDB 악보 저장
- `src/lib/scoreCloud.ts`: Supabase 악보 API 연결
- `src/lib/supabase.ts`: 인증 클라이언트
- `src/App.test.tsx`: 주요 동작 자동 테스트
- `supabase/functions/`: Supabase 서버 함수
