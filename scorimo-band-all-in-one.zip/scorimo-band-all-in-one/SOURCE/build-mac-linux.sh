#!/usr/bin/env sh
set -eu
corepack enable
pnpm install
pnpm test
pnpm build
echo "Build complete: dist/"
