#!/usr/bin/env sh
set -eu
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 20 이상이 필요합니다: https://nodejs.org/"
  exit 1
fi
corepack enable
pnpm install
pnpm dev
