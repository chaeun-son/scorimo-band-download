# SCORIMO BAND 이어서 개발하기

## 1. 실행

```bash
pnpm install
pnpm dev
```

## 2. 검증

```bash
pnpm test
pnpm run build
```

## 3. 주요 파일

- `src/App.tsx` — 전체 화면과 사용자 흐름
- `src/index.css` — 디자인과 반응형 스타일
- `src/lib/supabase.ts` — Supabase 클라이언트
- `src/lib/scoreStorage.ts` — 악보 오프라인 저장
- `src/lib/scoreCloud.ts` — 악보 클라우드 동기화
- `supabase/functions/server/index.tsx` — 악보 업로드·조회·삭제 서버 API

## 4. 환경 변수

Vercel 또는 로컬 `.env.local`에 다음 값을 설정할 수 있습니다.

```text
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
```

공개 클라이언트 키만 사용하고 Service Role Key는 브라우저 코드에 넣지 마세요.

## 5. 아직 필요한 운영 설정

- Supabase Edge Function 배포
- Google OAuth 공급자 활성화
- 밴드별 데이터베이스와 권한 정책
- 커스텀 도메인 연결

현재 GitHub 저장소는 `https://github.com/chaeun-son/scorimo-band`입니다.
