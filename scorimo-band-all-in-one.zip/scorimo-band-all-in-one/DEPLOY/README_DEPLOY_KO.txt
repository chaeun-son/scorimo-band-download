SCORIMO BAND 정적 배포 파일

이 폴더의 내용을 정적 웹 호스팅의 루트에 업로드하면 됩니다.
지원 예: Netlify, Vercel, Cloudflare Pages, GitHub Pages, Nginx

주의:
- index.html을 파일 탐색기에서 직접 여는 대신 웹 서버로 제공하세요.
- Supabase 인증 리디렉션 URL에 실제 배포 주소를 등록하세요.
- 원본 수정과 재빌드가 필요하면 함께 제공된 SOURCE 폴더를 사용하세요.
