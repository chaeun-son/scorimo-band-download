SCORIMO BAND 전체 프로젝트 패키지

이 ZIP 하나에 모두 들어 있습니다.

1. 프로그램을 수정하고 실행하려면 SOURCE 폴더를 사용하세요.
   - Windows: SOURCE/start-windows.bat 더블클릭
   - macOS/Linux: SOURCE/start-mac-linux.sh 실행

2. 이미 빌드된 웹 파일이 필요하면 DEPLOY 폴더를 사용하세요.
   - DEPLOY 폴더 전체를 웹 호스팅에 업로드하면 됩니다.

3. 자세한 안내는 SOURCE/README_FIRST_KO.md를 확인하세요.
